import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'
import { Skeleton } from './feedback'

const TONES = {
  primary: 'bg-primary-soft text-primary',
  accent: 'bg-accent-soft text-accent',
  success: 'bg-success-soft text-success',
  warning: 'bg-warning-soft text-warning',
  danger: 'bg-danger-soft text-danger',
  info: 'bg-info-soft text-info',
  neutral: 'bg-surface-3 text-fg-soft',
}

/** KPI tile. `value` must come from real data; pass null to show "—". */
export function StatCard({ label, value, icon, tone = 'primary', hint, loading, className }: {
  label: ReactNode; value: ReactNode; icon?: ReactNode; tone?: keyof typeof TONES; hint?: ReactNode; loading?: boolean; className?: string
}) {
  return (
    <div className={cn('ff-card group relative overflow-hidden p-4 transition-shadow hover:shadow-pop', className)}>
      <div className="flex items-start justify-between gap-3">
        <p className="text-[0.8rem] font-medium text-muted">{label}</p>
        {icon && <span className={cn('grid size-8 place-items-center rounded-lg [&_svg]:size-4', TONES[tone])}>{icon}</span>}
      </div>
      {loading ? <Skeleton className="mt-3 h-7 w-20" /> : <p className="mt-2 font-display text-2xl font-bold tracking-tight text-fg tabular-nums">{value ?? '—'}</p>}
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  )
}
