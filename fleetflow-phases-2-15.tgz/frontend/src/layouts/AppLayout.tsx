import {
  Bell, Check, CheckCheck, ChevronsUpDown, LogOut, Menu, PanelLeftClose, PanelLeftOpen, Plus, ShieldCheck, Smartphone, UserCog, X,
} from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { adminNavigation, companyNavigation, filterNavigation, type NavGroup } from '@/app/navigation'
import { Logo, LogoMark } from '@/components/brand/Logo'
import { ThemeToggle } from '@/components/ThemeToggle'
import {
  Avatar, Badge, Button, DropdownContent, DropdownItem, DropdownLabel, DropdownMenu, DropdownSeparator, DropdownTrigger, Spinner, Tooltip,
} from '@/components/ui'
import { companyApi } from '@/features/auth/api/authApi'
import { ago } from '@/lib/format'
import { setActiveCompany } from '@/lib/http'
import { cn } from '@/lib/utils'
import { useInterval } from '@/hooks/usePaged'
import { useAuth } from '@/stores/auth'
import { useNotifications } from '@/stores/notifications'

export const ROLE_LABELS: Record<string, string> = {
  company_admin: 'Company Admin', fleet_manager: 'Fleet Manager', dispatcher: 'Dispatcher',
  driver: 'Driver', accountant: 'Accountant', customer: 'Customer',
}

function SidebarNav({ groups, collapsed, onNavigate }: { groups: NavGroup[]; collapsed: boolean; onNavigate?: () => void }) {
  return (
    <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-4" aria-label="Main">
      {groups.map((group) => (
        <div key={group.label}>
          {!collapsed && <p className="mb-2 px-3 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-sidebar-muted">{group.label}</p>}
          <ul className="space-y-0.5">
            {group.items.map((item) => {
              const Icon = item.icon
              const node = (
                <NavLink
                  to={item.to}
                  end={item.to === '/app' || item.to === '/admin'}
                  onClick={onNavigate}
                  className={({ isActive }) =>
                    cn('group relative flex h-10 items-center gap-3 rounded-lg px-3 text-[0.875rem] font-medium transition-colors', collapsed && 'justify-center px-0',
                      isActive
                        ? 'bg-sidebar-active text-white before:absolute before:-left-3 before:top-2 before:bottom-2 before:w-[3px] before:rounded-r-full before:bg-gradient-to-b before:from-[#5b8cff] before:to-[#2dd4bf]'
                        : 'text-sidebar-fg hover:bg-white/[0.05] hover:text-white')
                  }
                >
                  <Icon className="size-[18px] shrink-0" />
                  {!collapsed && <span className="truncate">{item.label}</span>}
                </NavLink>
              )
              return <li key={item.to}>{collapsed ? <Tooltip content={item.label} side="right">{node}</Tooltip> : node}</li>
            })}
          </ul>
        </div>
      ))}
    </nav>
  )
}

function WorkspaceSwitcher({ collapsed }: { collapsed: boolean }) {
  const { user, refresh } = useAuth()
  const navigate = useNavigate()
  const current = user?.current_company
  if (!current) return null

  async function switchTo(id: string) {
    try {
      await companyApi.switch(id)
      setActiveCompany(id)
      await refresh()
      navigate('/app')
      toast.success('Workspace switched')
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  return (
    <DropdownMenu>
      <DropdownTrigger asChild>
        <button className={cn('flex w-full items-center gap-3 rounded-xl border border-sidebar-border bg-white/[0.03] p-2 text-left transition-colors hover:bg-white/[0.06]', collapsed && 'justify-center p-1.5')}>
          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-[#2459e6] to-[#0fa89a] text-xs font-bold text-white">{current.name.slice(0, 2).toUpperCase()}</span>
          {!collapsed && (
            <>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-white">{current.name}</span>
                <span className="block truncate text-xs text-sidebar-muted">{current.city} · {current.currency}</span>
              </span>
              <ChevronsUpDown className="size-4 text-sidebar-muted" />
            </>
          )}
        </button>
      </DropdownTrigger>
      <DropdownContent align="start" className="w-64">
        <DropdownLabel>Workspaces</DropdownLabel>
        {(user?.companies ?? []).map((c) => (
          <DropdownItem key={c.id} onSelect={() => c.id !== current.id && switchTo(c.id)}>
            <span className="grid size-6 place-items-center rounded-md bg-surface-3 text-[10px] font-bold text-fg">{c.name.slice(0, 2).toUpperCase()}</span>
            <span className="flex-1 truncate">{c.name}</span>
            {c.id === current.id && <Check className="!text-primary" />}
          </DropdownItem>
        ))}
        <DropdownSeparator />
        <DropdownItem onSelect={() => navigate('/onboarding')}><Plus /> New company</DropdownItem>
      </DropdownContent>
    </DropdownMenu>
  )
}

const TONE_DOT: Record<string, string> = { info: 'bg-info', success: 'bg-success', warning: 'bg-warning', danger: 'bg-danger' }

function NotificationBell() {
  const { unread, items, loading, load, markRead, markAll, refreshCount } = useNotifications()
  const navigate = useNavigate()
  useEffect(() => { void refreshCount() }, [refreshCount])
  useInterval(() => void refreshCount(), 30_000)

  return (
    <DropdownMenu onOpenChange={(o) => o && void load()}>
      <DropdownTrigger asChild>
        <Button variant="ghost" size="icon" aria-label={`Notifications${unread ? ` (${unread} unread)` : ''}`} className="relative">
          <Bell />
          {unread > 0 && <span className="absolute right-1.5 top-1.5 grid min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold leading-4 text-white ring-2 ring-bg">{unread > 9 ? '9+' : unread}</span>}
        </Button>
      </DropdownTrigger>
      <DropdownContent align="end" className="w-[22rem] p-0">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="text-sm font-semibold">Notifications</p>
          {unread > 0 && <button className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline" onClick={() => void markAll()}><CheckCheck className="size-3.5" /> Mark all read</button>}
        </div>
        <div className="max-h-96 overflow-y-auto">
          {loading && items.length === 0 ? <div className="grid place-items-center py-8"><Spinner className="text-primary" /></div>
            : items.length === 0 ? <p className="px-4 py-10 text-center text-sm text-muted">You're all caught up.</p>
            : items.map((n) => (
              <DropdownItem key={n.id} className="items-start gap-3 rounded-none border-b border-border px-4 py-3 last:border-0"
                onSelect={() => { if (!n.read) void markRead(n.id); if (n.data.link) navigate(n.data.link) }}>
                <span className={cn('mt-1.5 size-2 shrink-0 rounded-full', n.read ? 'bg-transparent' : TONE_DOT[n.data.tone] ?? 'bg-primary')} />
                <span className="min-w-0 flex-1">
                  <span className={cn('block text-[13px] leading-snug', n.read ? 'text-muted' : 'font-semibold text-fg')}>{n.data.title}</span>
                  {n.data.body && <span className="mt-0.5 block truncate text-xs text-muted">{n.data.body}</span>}
                  <span className="mt-1 block text-[11px] text-subtle">{ago(n.created_at)}</span>
                </span>
              </DropdownItem>
            ))}
        </div>
        <Link to="/app/notifications" className="block border-t border-border px-4 py-2.5 text-center text-xs font-semibold text-primary hover:bg-surface-2">View all</Link>
      </DropdownContent>
    </DropdownMenu>
  )
}

export function UserMenu({ admin }: { admin?: boolean }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  if (!user) return null
  return (
    <DropdownMenu>
      <DropdownTrigger asChild>
        <button className="flex items-center gap-2.5 rounded-full p-0.5 pr-2 transition-colors hover:bg-surface-3" aria-label="Account menu">
          <Avatar name={user.name} className="size-8" />
          <span className="hidden text-left leading-tight md:block">
            <span className="block text-sm font-semibold text-fg">{user.name}</span>
            <span className="block text-xs text-muted">{admin ? 'Platform admin' : ROLE_LABELS[user.roles[0] ?? ''] ?? 'Member'}</span>
          </span>
        </button>
      </DropdownTrigger>
      <DropdownContent align="end">
        <div className="px-2.5 py-2">
          <p className="text-sm font-semibold">{user.name}</p>
          <p className="truncate text-xs text-muted">{user.email}</p>
        </div>
        <DropdownSeparator />
        {user.current_company && <DropdownItem onSelect={() => navigate('/app/profile')}><UserCog /> Profile & security</DropdownItem>}
        {user.roles.includes('driver') && <DropdownItem onSelect={() => navigate('/driver')}><Smartphone /> Driver app</DropdownItem>}
        {user.is_super_admin && !admin && <DropdownItem onSelect={() => navigate('/admin')}><ShieldCheck /> Platform admin</DropdownItem>}
        {admin && user.current_company && <DropdownItem onSelect={() => navigate('/app')}><ShieldCheck /> Back to workspace</DropdownItem>}
        <DropdownSeparator />
        <DropdownItem className="data-[highlighted]:text-danger" onSelect={async () => { await logout(); navigate('/login', { replace: true }) }}>
          <LogOut /> Sign out
        </DropdownItem>
      </DropdownContent>
    </DropdownMenu>
  )
}

function VerifyBanner() {
  const user = useAuth((s) => s.user)
  const [sent, setSent] = useState(false)
  if (!user || user.email_verified) return null
  return (
    <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 bg-warning-soft px-4 py-2 text-center text-xs font-medium text-warning">
      Please verify your email address ({user.email}).
      <button className="font-semibold underline" disabled={sent} onClick={async () => {
        const { api } = await import('@/lib/api')
        await api.post('/auth/email/resend').catch(() => {})
        setSent(true)
        toast.success('Verification email sent')
      }}>{sent ? 'Sent' : 'Resend link'}</button>
    </div>
  )
}

export function AppLayout({ variant = 'company' }: { variant?: 'company' | 'admin' }) {
  const { user } = useAuth()
  const location = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem('ff-sidebar') === 'collapsed' } catch { return false }
  })
  useEffect(() => setMobileOpen(false), [location.pathname])
  useEffect(() => { try { localStorage.setItem('ff-sidebar', collapsed ? 'collapsed' : 'open') } catch { /* ignore */ } }, [collapsed])

  const groups = useMemo(() => variant === 'admin' ? adminNavigation : filterNavigation(companyNavigation, user?.permissions ?? []), [user?.permissions, variant])

  const sidebar = (isMobile: boolean) => {
    const c = collapsed && !isMobile
    return (
      <div className="relative flex h-full flex-col bg-sidebar text-sidebar-fg">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-[radial-gradient(400px_200px_at_0%_0%,rgba(91,140,255,0.18),transparent)]" />
        <div className={cn('relative flex h-16 items-center px-5', c && 'justify-center px-0')}>
          <Link to={variant === 'admin' ? '/admin' : '/app'}>{c ? <LogoMark /> : <Logo light />}</Link>
          {isMobile && (
            <Button variant="ghost" size="icon-sm" className="ml-auto text-sidebar-fg hover:bg-white/10 hover:text-white" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X /></Button>
          )}
        </div>
        {variant === 'admin'
          ? !c && <div className="relative mx-3 rounded-xl border border-sidebar-border bg-white/[0.03] px-3 py-2.5 text-xs"><p className="font-semibold text-white">Platform administration</p><p className="text-sidebar-muted">All companies</p></div>
          : <div className={cn('relative px-3 pt-1', c && 'px-2')}><WorkspaceSwitcher collapsed={c} /></div>}
        <SidebarNav groups={groups} collapsed={c} onNavigate={() => setMobileOpen(false)} />
        {!isMobile && (
          <div className="relative border-t border-sidebar-border p-3">
            <button onClick={() => setCollapsed((v) => !v)} aria-label={c ? 'Expand sidebar' : 'Collapse sidebar'}
              className={cn('flex h-9 w-full items-center gap-3 rounded-lg px-3 text-sm text-sidebar-muted transition-colors hover:bg-white/[0.05] hover:text-white', c && 'justify-center px-0')}>
              {c ? <PanelLeftOpen className="size-[18px]" /> : <><PanelLeftClose className="size-[18px]" /> Collapse</>}
            </button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="min-h-dvh">
      <aside className={cn('fixed inset-y-0 left-0 z-30 hidden border-r border-sidebar-border transition-[width] duration-200 lg:block', collapsed ? 'w-[76px]' : 'w-[264px]')}>{sidebar(false)}</aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-navy-950/60 backdrop-blur-sm animate-fade-in" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-[280px] max-w-[85vw] shadow-pop animate-slide-up">{sidebar(true)}</aside>
        </div>
      )}
      <div className={cn('transition-[padding] duration-200', collapsed ? 'lg:pl-[76px]' : 'lg:pl-[264px]')}>
        <VerifyBanner />
        <header className="sticky top-0 z-20 flex h-16 items-center gap-2 border-b border-border bg-bg/75 px-4 backdrop-blur-xl sm:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu /></Button>
          <div className="min-w-0 flex-1">
            {variant === 'admin' ? <Badge tone="primary"><ShieldCheck /> Super Admin</Badge>
              : user?.current_company?.status === 'active' && (
                <span className="hidden items-center gap-2 text-xs font-medium text-muted sm:inline-flex">
                  <span className="relative flex size-2"><span className="absolute inset-0 animate-ping rounded-full bg-success/60" /><span className="relative size-2 rounded-full bg-success" /></span>
                  {user.current_company.name} · {user.current_company.timezone}
                </span>
              )}
          </div>
          <ThemeToggle />
          {variant === 'company' && <NotificationBell />}
          <div className="mx-1 h-6 w-px bg-border" />
          <UserMenu admin={variant === 'admin'} />
        </header>
        <main className="mx-auto w-full max-w-[1440px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
