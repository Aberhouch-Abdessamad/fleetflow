import {
  AlertTriangle, Banknote, CheckCircle2, Clock, FileWarning, Package, PackageCheck, PackageX, Percent, Plus, Radio, Truck, UserCheck, Users, Wrench,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { BarsChart, ChartCard, ShareList, TrendChart } from '@/components/charts/Charts'
import { FleetMap, escapeHtml } from '@/components/map/FleetMap'
import { DateRangeSelect, type RangeValue } from '@/components/shared/DateRangeSelect'
import { Badge, Button, Card, CardHeader, EmptyState, StatCard, StatusBadge } from '@/components/ui'
import { useAsync } from '@/hooks/useAsync'
import { useInterval } from '@/hooks/usePaged'
import { api } from '@/lib/api'
import { ago, date, label, minutes, money, num, pct } from '@/lib/format'
import { useAuth } from '@/stores/auth'

interface Dashboard {
  range: { preset: string; bucket: string }
  kpis: Record<string, number | string | null>
  charts: {
    deliveries_over_time: { date: string; created: number; delivered: number; failed: number }[]
    status_distribution: { status: string; count: number }[]
    fleet_utilization: { date: string; vehicles_used: number; rate: number | null }[]
    revenue_over_time: { date: string; amount: string }[]
    fuel_expenses: { date: string; amount: string }[]
    maintenance_expenses: { date: string; amount: string }[]
    driver_performance: { driver_id: number; name: string; delivered: number; failed: number }[]
    average_delivery_minutes: number | null
  }
  widgets: {
    recent_deliveries: { id: number; reference: string; status: string; recipient: string; city: string | null; driver: string | null; created_at: string }[]
    active_drivers: { id: number; name: string; vehicle: string | null; last_seen: string | null; active_deliveries: number }[]
    upcoming_maintenance: { id: number; title: string; vehicle: string; vehicle_id: number; date: string; overdue: boolean }[]
    expiring_documents: { type: string; subject: string; link: string; expires: string; expired: boolean }[]
    recent_expenses: { id: number; description: string; category: string; amount: string; status: string; date: string }[]
    delivery_exceptions: { id: number; reference: string; reason: string; at: string }[]
    live_fleet: { id: number; registration_number: string; status: string; latitude: number; longitude: number; located_at: string; freshness: string }[]
  }
}

function greeting(tz?: string) {
  const h = Number(new Intl.DateTimeFormat('en-GB', { hour: 'numeric', hour12: false, timeZone: tz }).format(new Date()))
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'
}

export default function DashboardPage() {
  const { user, can } = useAuth()
  const navigate = useNavigate()
  const company = user!.current_company!
  const [range, setRange] = useState<RangeValue>({ range: 'last_30_days' })
  const { data, loading, reload } = useAsync(() => api.get<Dashboard>('/dashboard', { ...range }), [range.range, range.from, range.to])
  useInterval(() => void reload(), 60_000)
  const k = data?.kpis ?? {}
  const c = data?.charts
  const w = data?.widgets
  const financial = k.delivery_revenue !== null && k.delivery_revenue !== undefined

  const costs = useMemo(() => c ? c.fuel_expenses.map((f, i) => ({ date: f.date, fuel: Number(f.amount), maintenance: Number(c.maintenance_expenses[i]?.amount ?? 0) })) : [], [c])
  const revenue = useMemo(() => c?.revenue_over_time.map((r) => ({ date: r.date, revenue: Number(r.amount) })) ?? [], [c])
  const fmtMoney = (v: number) => money(v).replace(/\.00$/, '')

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-2xl bg-navy-900 px-6 py-6 text-white shadow-pop sm:px-8 animate-slide-up">
        <div className="pointer-events-none absolute -right-20 -top-24 size-80 rounded-full bg-[#2459e6]/40 blur-[90px]" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 size-72 rounded-full bg-[#0fa89a]/25 blur-[90px]" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.08)_1px,transparent_1px)] [background-size:20px_20px] [mask-image:linear-gradient(to_left,black,transparent_70%)]" />
        <div className="relative flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-sm font-medium text-white/60">{new Intl.DateTimeFormat(undefined, { weekday: 'long', day: 'numeric', month: 'long', timeZone: company.timezone }).format(new Date())}</p>
            <h1 className="mt-1 text-[1.7rem] font-extrabold text-white sm:text-3xl">{greeting(company.timezone)}, {user!.name.split(' ')[0]}</h1>
            <p className="mt-1.5 text-white/70">
              {k.active_deliveries !== undefined ? <><b className="text-white">{String(k.active_deliveries)}</b> deliveries in progress · <b className="text-white">{String(k.vehicles_on_road)}</b> vehicles on the road · <b className="text-white">{String(k.on_duty_drivers)}</b> drivers on duty</> : 'Loading operations…'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 [&_select]:border-white/15 [&_select]:bg-white/10 [&_select]:text-white [&_input]:border-white/15 [&_input]:bg-white/10 [&_input]:text-white">
            <DateRangeSelect value={range} onChange={setRange} />
            {can('deliveries.create') && <Button onClick={() => navigate('/app/deliveries/new')} className="bg-white text-navy-900 hover:bg-white/90 hover:shadow-none"><Plus /> New delivery</Button>}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StatCard loading={loading} label="Total vehicles" value={num(k.total_vehicles as number)} icon={<Truck />} hint={`${num(k.vehicles_in_maintenance as number)} in maintenance`} />
        <StatCard loading={loading} label="Available vehicles" value={num(k.available_vehicles as number)} icon={<CheckCircle2 />} tone="success" />
        <StatCard loading={loading} label="On the road" value={num(k.vehicles_on_road as number)} icon={<Radio />} tone="accent" />
        <StatCard loading={loading} label="Active drivers" value={num(k.active_drivers as number)} icon={<Users />} tone="info" hint={`${num(k.on_duty_drivers as number)} on duty`} />
        <StatCard loading={loading} label="Available drivers" value={num(k.available_drivers as number)} icon={<UserCheck />} tone="success" />
        <StatCard loading={loading} label="Deliveries today" value={num(k.deliveries_today as number)} icon={<Package />} tone="primary" />
        <StatCard loading={loading} label="Total deliveries" value={num(k.total_deliveries as number)} icon={<Package />} tone="neutral" hint="Created in period" />
        <StatCard loading={loading} label="Pending" value={num(k.pending_deliveries as number)} icon={<Clock />} tone="warning" hint="Awaiting assignment" />
        <StatCard loading={loading} label="Completed" value={num(k.completed_deliveries as number)} icon={<PackageCheck />} tone="success" />
        <StatCard loading={loading} label="Failed" value={num(k.failed_deliveries as number)} icon={<PackageX />} tone="danger" />
        <StatCard loading={loading} label="On-time rate" value={pct(k.on_time_rate as number | null)} icon={<Percent />} tone="accent" hint={c ? `Avg ${minutes(c.average_delivery_minutes)} per delivery` : undefined} />
        <StatCard loading={loading} label="Delivery revenue" value={financial ? money(k.delivery_revenue as string) : '—'} icon={<Banknote />} tone="primary" hint={financial ? `Success rate ${pct(k.success_rate as number | null)}` : 'Requires finance access'} />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <ChartCard className="xl:col-span-2" title="Deliveries over time" description="Created, delivered and failed per day" loading={loading} empty={!c?.deliveries_over_time.some((x) => x.created || x.delivered || x.failed)}>
          <TrendChart data={c?.deliveries_over_time ?? []} series={[{ key: 'created', label: 'Created' }, { key: 'delivered', label: 'Delivered' }, { key: 'failed', label: 'Failed', color: 'var(--chart-5)' }]} />
        </ChartCard>
        <ChartCard title="Status distribution" description="Deliveries created in the period" loading={loading} empty={!c?.status_distribution.length}>
          <ShareList items={(c?.status_distribution ?? []).sort((a, b) => b.count - a.count).map((s) => ({ label: label(s.status), value: s.count }))} />
        </ChartCard>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <ChartCard title="Fleet utilisation" description="Share of active vehicles that ran at least one delivery" loading={loading} empty={!c?.fleet_utilization.some((x) => x.vehicles_used)}>
          <BarsChart data={(c?.fleet_utilization ?? []).map((u) => ({ date: u.date, rate: u.rate ?? 0 }))} x="date" series={[{ key: 'rate', label: 'Utilisation' }]} format={(v) => `${v}%`} />
        </ChartCard>
        {financial && (
          <ChartCard title="Delivery revenue" description="Fees of delivered orders" loading={loading} empty={!revenue.some((r) => r.revenue)}>
            <BarsChart data={revenue} x="date" series={[{ key: 'revenue', label: 'Revenue' }]} format={fmtMoney} />
          </ChartCard>
        )}
        <ChartCard title="Fuel & maintenance costs" description="Recorded fuel purchases and completed maintenance" loading={loading} empty={!costs.some((x) => x.fuel || x.maintenance)}>
          <BarsChart data={costs} x="date" series={[{ key: 'fuel', label: 'Fuel', color: 'var(--chart-2)' }, { key: 'maintenance', label: 'Maintenance', color: 'var(--chart-3)' }]} format={fmtMoney} />
        </ChartCard>
        {!financial && (
          <ChartCard title="Driver performance" description="Delivered vs failed" loading={loading} empty={!c?.driver_performance.length}>
            <BarsChart layout="horizontal" data={c?.driver_performance ?? []} x="name" labelFormat={(l) => l} series={[{ key: 'delivered', label: 'Delivered' }, { key: 'failed', label: 'Failed', color: 'var(--chart-5)' }]} />
          </ChartCard>
        )}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="overflow-hidden xl:col-span-2">
          <CardHeader title="Live fleet" description={`${w?.live_fleet.filter((v) => v.freshness === 'live').length ?? 0} live · ${w?.live_fleet.length ?? 0} with a known position`} action={can('tracking.view') && <Button size="sm" variant="ghost" onClick={() => navigate('/app/tracking')}>Open map</Button>} />
          <div className="h-80 p-3">
            {w && w.live_fleet.length === 0
              ? <EmptyState className="h-full border border-dashed border-border" icon={<Radio />} title="No GPS positions yet" description="Vehicles appear once drivers share their location from the driver app." />
              : <FleetMap markers={(w?.live_fleet ?? []).map((v) => ({ id: v.id, lat: v.latitude, lng: v.longitude, kind: 'vehicle', tone: v.freshness === 'live' ? 'live' : 'stale', label: v.registration_number, popup: `<b>${escapeHtml(v.registration_number)}</b><br/>${escapeHtml(label(v.status))} · ${escapeHtml(ago(v.located_at))}` }))} />}
          </div>
        </Card>
        {financial ? (
          <ChartCard title="Driver performance" description="Delivered vs failed in the period" loading={loading} empty={!c?.driver_performance.length}>
            <BarsChart layout="horizontal" height={300} data={c?.driver_performance ?? []} x="name" labelFormat={(l) => l} series={[{ key: 'delivered', label: 'Delivered' }, { key: 'failed', label: 'Failed', color: 'var(--chart-5)' }]} />
          </ChartCard>
        ) : (
          <Card><CardHeader title="Active drivers" icon={<Users />} />
            <ul className="divide-y divide-border">{(w?.active_drivers ?? []).map((d) => <li key={d.id} className="flex items-center justify-between px-5 py-3 text-sm"><Link to={`/app/drivers/${d.id}`} className="font-semibold hover:text-primary">{d.name}</Link><span className="text-xs text-muted">{d.vehicle ?? '—'} · {d.active_deliveries} active</span></li>)}
              {w?.active_drivers.length === 0 && <li className="px-5 py-8 text-center text-sm text-muted">No drivers on duty</li>}</ul>
          </Card>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-3">
        <Card className="xl:col-span-2"><CardHeader title="Recent deliveries" icon={<Package />} action={<Button size="sm" variant="ghost" onClick={() => navigate('/app/deliveries')}>View all</Button>} />
          <ul className="divide-y divide-border">
            {(w?.recent_deliveries ?? []).map((d) => (
              <li key={d.id}><Link to={`/app/deliveries/${d.id}`} className="flex items-center gap-4 px-5 py-3 text-sm transition-colors hover:bg-surface-2">
                <span className="w-40 shrink-0 font-semibold">{d.reference}</span>
                <span className="min-w-0 flex-1 truncate text-fg-soft">{d.recipient}{d.city ? ` · ${d.city}` : ''}</span>
                <span className="hidden text-xs text-muted sm:block">{d.driver ?? 'Unassigned'}</span>
                <StatusBadge status={d.status} />
              </Link></li>
            ))}
            {w?.recent_deliveries.length === 0 && <li className="px-5 py-8 text-center text-sm text-muted">No deliveries yet</li>}
          </ul>
        </Card>
        <Card><CardHeader title="Delivery exceptions" icon={<AlertTriangle />} />
          <ul className="divide-y divide-border">
            {(w?.delivery_exceptions ?? []).map((x, i) => (
              <li key={`${x.id}-${i}`}><Link to={`/app/deliveries/${x.id}`} className="block px-5 py-3 text-sm hover:bg-surface-2"><p className="font-semibold">{x.reference}</p><p className="text-xs text-danger">{x.reason}</p></Link></li>
            ))}
            {w?.delivery_exceptions.length === 0 && <li className="px-5 py-8 text-center text-sm text-muted">No exceptions</li>}
          </ul>
        </Card>
        <Card><CardHeader title="Upcoming maintenance" icon={<Wrench />} action={can('maintenance.view') && <Button size="sm" variant="ghost" onClick={() => navigate('/app/maintenance')}>All</Button>} />
          <ul className="divide-y divide-border">
            {(w?.upcoming_maintenance ?? []).map((m) => (
              <li key={m.id} className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
                <div className="min-w-0"><p className="truncate font-semibold">{m.title}</p><Link to={`/app/vehicles/${m.vehicle_id}`} className="text-xs text-primary">{m.vehicle}</Link></div>
                <Badge tone={m.overdue ? 'danger' : 'info'}>{date(m.date)}</Badge>
              </li>
            ))}
            {w?.upcoming_maintenance.length === 0 && <li className="px-5 py-8 text-center text-sm text-muted">Nothing scheduled</li>}
          </ul>
        </Card>
        <Card><CardHeader title="Expiring documents" icon={<FileWarning />} description="Next 30 days" />
          <ul className="divide-y divide-border">
            {(w?.expiring_documents ?? []).map((x, i) => (
              <li key={i}><Link to={x.link} className="flex items-center justify-between gap-3 px-5 py-3 text-sm hover:bg-surface-2">
                <div className="min-w-0"><p className="truncate font-semibold">{x.subject}</p><p className="text-xs text-muted">{x.type}</p></div>
                <Badge tone={x.expired ? 'danger' : 'warning'}>{x.expired ? 'Expired' : date(x.expires)}</Badge>
              </Link></li>
            ))}
            {w?.expiring_documents.length === 0 && <li className="px-5 py-8 text-center text-sm text-muted">All documents valid</li>}
          </ul>
        </Card>
        <Card><CardHeader title="Recent expenses" icon={<Banknote />} action={can('expenses.view') && <Button size="sm" variant="ghost" onClick={() => navigate('/app/expenses')}>All</Button>} />
          <ul className="divide-y divide-border">
            {(w?.recent_expenses ?? []).map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
                <div className="min-w-0"><p className="truncate font-semibold">{e.description}</p><p className="text-xs text-muted">{label(e.category)} · {date(e.date)}</p></div>
                <div className="text-right"><p className="font-semibold tabular-nums">{money(e.amount)}</p><StatusBadge status={e.status} /></div>
              </li>
            ))}
            {w?.recent_expenses.length === 0 && <li className="px-5 py-8 text-center text-sm text-muted">No expenses</li>}
          </ul>
        </Card>
      </div>
    </div>
  )
}
