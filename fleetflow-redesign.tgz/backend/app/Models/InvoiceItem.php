<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InvoiceItem extends Model
{
    protected $fillable = ['delivery_id', 'description', 'quantity', 'unit_price', 'total_price'];

    protected function casts(): array
    {
        return ['quantity' => 'decimal:2', 'unit_price' => 'decimal:2', 'total_price' => 'decimal:2'];
    }

    public function delivery(): BelongsTo
    {
        return $this->belongsTo(Delivery::class)->withTrashed();
    }
}
